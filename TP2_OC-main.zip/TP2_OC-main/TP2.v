`timescale 1ns / 1ps

// ===================================================================================================================
// Decodificador Decimal de 7 Segmentos (Apenas números de 0 a 9 - Anodo Comum)
// ===================================================================================================================
module dec7seg_decimal (
    input      [3:0] digito, 
    output reg [6:0] seg    
);
    always @(*) begin
        case (digito)
            4'd0:    seg = 7'b1000000;
            4'd1:    seg = 7'b1111001;
            4'd2:    seg = 7'b0100100;
            4'd3:    seg = 7'b0110000;
            4'd4:    seg = 7'b0011001;
            4'd5:    seg = 7'b0010010;
            4'd6:    seg = 7'b0000010;
            4'd7:    seg = 7'b1111000;
            4'd8:    seg = 7'b0000000;
            4'd9:    seg = 7'b0010000;
            default: seg = 7'b1111111;
        endcase
    end
endmodule


// ===================================================================================================================
// Program Counter (Borda de Descida)
// ===================================================================================================================
module pc (
    input        clk,
    input        reset,
    input        stop,       
    input  [31:0] next_pc,
    output reg [31:0] current_pc
);
    always @(negedge clk or negedge reset) begin
        if (!reset)          
            current_pc <= 32'b0;
        else if (!stop)      
            current_pc <= next_pc;
    end
endmodule


// ===================================================================================================================
// Memória de Instruções
// ===================================================================================================================
module instr_mem (
    input  [31:0] addr,
    output [31:0] instruction 
);
    reg [31:0] mem [0:63];
    integer i;

    initial begin
        for (i = 0; i < 64; i = i + 1) mem[i] = 32'b0;

        mem[0] = 32'b00000000000000000010000010000011; // 00: lw x1, 0(x0)
        mem[1] = 32'b00000000010000000010000100000011; // 01: lw x2, 4(x0)

        // CORRIGIDO: rd agora é x1 (00001) em ambas as instruções.
        // Original com bug: rd=x11 (01011) em mem[2] e rd=x12 (01100) em mem[3].
        mem[2] = 32'b00000110001100000000000010010011; // 02: addi x1, x0, 99  [rd=00001]
        mem[3] = 32'b00000011011100000000000010010011; // 03: addi x1, x0, 55  [rd=00001]

        mem[4] = 32'b00000000101001000000010010010011; // 04: addi x9, x8, 10
        mem[5] = 32'b00000000001001001101010100110011; // 05: srl x10, x9, x2
        mem[6] = 32'b00000000101000000010100000100011; // 06: sw x10, 16(x0)
        mem[7] = 32'b00000000000100001000010001100011; // 07: beq x1, x1, 8
        mem[8] = 32'b01000000001000001000001110110011; // 08: sub x7, x1, x2
        mem[9] = 32'b00000000011100010100010000110011; // 09: xor x8, x2, x7
    end

    assign instruction = mem[addr >> 2];
endmodule


// ===================================================================================================================
// Banco de Registradores - COM SUPORTE A RESET PELO BOTÃO (KEY 1)
// ===================================================================================================================
module reg_file (
    input        clk,
    input        reset,
    input        reg_write,
    input  [4:0] rs1, rs2, rd,
    input  [31:0] write_data,
    output [31:0] read_data1,
    output [31:0] read_data2,
    output [31:0] reg_x1     
);
    reg [31:0] regs [0:31];

    assign read_data1 = (rs1 == 0) ? 32'b0 : regs[rs1];
    assign read_data2 = (rs2 == 0) ? 32'b0 : regs[rs2];
    assign reg_x1 = regs[1];

    always @(negedge clk or negedge reset) begin
        if (!reset) begin
            regs[0]  <= 32'd0;
            regs[1]  <= 32'd10;  
            regs[2]  <= 32'd25;
            regs[3]  <= 32'd42;
            regs[4]  <= 32'd100;
            regs[5]  <= 32'd150;
            regs[6]  <= 32'd255;
            regs[7]  <= 32'd512;
            regs[8]  <= 32'd1024;
            regs[9]  <= 32'd2048;
            regs[10] <= 32'd4096;
            regs[11] <= 32'd7;
            regs[12] <= 32'd13;
            regs[13] <= 32'd19;
            regs[14] <= 32'd21;
            regs[15] <= 32'd33;
            regs[16] <= 32'd88;
            regs[17] <= 32'd99;
            regs[18] <= 32'd120;
            regs[19] <= 32'd300;
            regs[20] <= 32'd450;
            regs[21] <= 32'd777;
            regs[22] <= 32'd888;
            regs[23] <= 32'd999;
            regs[24] <= 32'd1234;
            regs[25] <= 32'd5678;
            regs[26] <= 32'd9101;
            regs[27] <= 32'd1121;
            regs[28] <= 32'd3141;
            regs[29] <= 32'd2718;
            regs[30] <= 32'd1414;
            regs[31] <= 32'd618;
        end 
        else if (reg_write && rd != 0) begin
            regs[rd] <= write_data;
        end
    end
endmodule


// ===================================================================================================================
// Gerador de Imediato
// ===================================================================================================================
module imm_gen (
    input  [31:0] instruction,
    output reg [31:0] imm_ext
);
    wire [6:0] opcode;
    assign opcode = instruction[6:0];
    always @(*) begin
        case (opcode)
            7'b0000011, 7'b0010011: imm_ext = {{20{instruction[31]}}, instruction[31:20]};
            7'b0100011:             imm_ext = {{20{instruction[31]}}, instruction[31:25], instruction[11:7]};
            7'b1100011:             imm_ext = {{19{instruction[31]}}, instruction[31], instruction[7], instruction[30:25], instruction[11:8], 1'b0};
            default:                imm_ext = 32'b0;
        endcase
    end
endmodule


// ===================================================================================================================
// Controle
// ===================================================================================================================
module control (
    input  [6:0] opcode,
    output reg   reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch,
    output reg [1:0] alu_op
);
    always @(*) begin
        case (opcode)
            7'b0000011: {reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch, alu_op} = 8'b1_1_0_1_1_0_00;
            7'b0100011: {reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch, alu_op} = 8'b0_0_1_1_0_0_00;
            7'b0110011: {reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch, alu_op} = 8'b1_0_0_0_0_0_10;
            7'b0010011: {reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch, alu_op} = 8'b1_0_0_1_0_0_11;
            7'b1100011: {reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch, alu_op} = 8'b0_0_0_0_0_1_01;
            default:    {reg_write, mem_read, mem_write, alu_src, mem_to_reg, branch, alu_op} = 8'b0_0_0_0_0_0_00;
        endcase
    end
endmodule


// ===================================================================================================================
// ALU Control
// ===================================================================================================================
module alu_control (
    input  [1:0] alu_op,
    input  [2:0] funct3,
    input  [6:0] funct7,
    output reg [3:0] alu_ctrl
);
    always @(*) begin
        case (alu_op)
            2'b00: alu_ctrl = 4'b0010;
            2'b01: alu_ctrl = 4'b0110;
            2'b11: alu_ctrl = 4'b0010;
            2'b10: begin
                case (funct3)
                    3'b000:  alu_ctrl = (funct7 == 7'b0100000) ? 4'b0110 : 4'b0010;
                    3'b111:  alu_ctrl = 4'b0000;
                    3'b110:  alu_ctrl = 4'b0001;
                    3'b100:  alu_ctrl = 4'b0011;
                    3'b001:  alu_ctrl = 4'b0100;
                    3'b101:  alu_ctrl = 4'b0101;
                    default: alu_ctrl = 4'b0010;
                endcase
            end
            default: alu_ctrl = 4'b0010;
        endcase
    end
endmodule


// ===================================================================================================================
// Mux ALU Src
// ===================================================================================================================
module mux_alu_src (
    input  [31:0] read_data2,
    input  [31:0] imm_ext,
    input         alu_src,
    output [31:0] b
);
    assign b = (alu_src) ? imm_ext : read_data2;
endmodule


// ===================================================================================================================
// ALU
// ===================================================================================================================
module alu (
    input  [31:0] a,
    input  [31:0] b,
    input  [3:0]  alu_ctrl,
    output reg [31:0] result,
    output zero
);
    always @(*) begin
        case (alu_ctrl)
            4'b0000: result = a & b;
            4'b0001: result = a | b;
            4'b0010: result = a + b;
            4'b0011: result = a ^ b;
            4'b0100: result = a << b[4:0];
            4'b0101: result = a >> b[4:0];
            4'b0110: result = a - b;
            default: result = 32'b0;
        endcase
    end

    assign zero = (result == 32'b0);
endmodule


// ===================================================================================================================
// Memória de Dados
// ===================================================================================================================
module data_mem (
    input        clk,
    input        mem_read,
    input        mem_write,
    input  [31:0] addr,
    input  [31:0] write_data,
    output reg [31:0] read_data
);
    reg [31:0] mem [0:63];

    initial begin
        mem[0]=32'd1;   mem[1]=32'd2;   mem[2]=32'd3;   mem[3]=32'd4;
        mem[4]=32'd5;   mem[5]=32'd6;   mem[6]=32'd7;   mem[7]=32'd8;
        mem[8]=32'd9;   mem[9]=32'd10;  mem[10]=32'd11; mem[11]=32'd12;
        mem[12]=32'd13; mem[13]=32'd14; mem[14]=32'd15; mem[15]=32'd16;
        mem[16]=32'd17; mem[17]=32'd17; mem[18]=32'd19; mem[19]=32'd20;
        mem[20]=32'd21; mem[21]=32'd22; mem[22]=32'd23; mem[23]=32'd24;
        mem[24]=32'd25; mem[25]=32'd26; mem[26]=32'd27; mem[27]=32'd28;
        mem[28]=32'd29; mem[29]=32'd30; mem[30]=32'd31; mem[31]=32'd32;
        mem[32]=32'd33; mem[33]=32'd34; mem[34]=32'd35; mem[35]=32'd36;
        mem[36]=32'd37; mem[37]=32'd38; mem[38]=32'd39; mem[39]=32'd40;
        mem[40]=32'd41; mem[41]=32'd42; mem[42]=32'd43; mem[43]=32'd44;
        mem[44]=32'd45; mem[45]=32'd46; mem[46]=32'd47; mem[47]=32'd48;
        mem[48]=32'd49; mem[49]=32'd50; mem[50]=32'd51; mem[51]=32'd52;
        mem[52]=32'd53; mem[53]=32'd54; mem[54]=32'd55; mem[55]=32'd56;
        mem[56]=32'd57; mem[57]=32'd58; mem[58]=32'd59; mem[59]=32'd60;
        mem[60]=32'd61; mem[61]=32'd62; mem[62]=32'd63; mem[63]=32'd64;
    end

    always @(negedge clk) begin
        if (mem_write)
            mem[addr >> 2] <= write_data;
    end

    always @(*) begin
        if (mem_read)
            read_data = mem[addr >> 2];
        else
            read_data = 32'b0;
    end
endmodule


// ===================================================================================================================
// Mux Mem To Reg
// ===================================================================================================================
module mux_mem_to_reg (
    input  [31:0] alu_result,
    input  [31:0] mem_read_data,
    input         mem_to_reg,
    output [31:0] write_data
);
    assign write_data = (mem_to_reg) ? mem_read_data : alu_result;
endmodule


// ===================================================================================================================
// Branch Control
// ===================================================================================================================
module branch_ctrl (
    input  branch,
    input  zero,
    output pcsrc
);
    assign pcsrc = branch & zero;
endmodule


// ===================================================================================================================
// Mux PC Src
// ===================================================================================================================
module mux_pcsrc (
    input  [31:0] pc_plus4,
    input  [31:0] pc_branch,
    input         pcsrc,
    output [31:0] next_pc
);
    assign next_pc = (pcsrc) ? pc_branch : pc_plus4;
endmodule


// ===================================================================================================================
// PC + 4
// ===================================================================================================================
module pc_plus4 (
    input  [31:0] current_pc,
    output [31:0] pc_plus4
);
    assign pc_plus4 = current_pc + 4;
endmodule


// ===================================================================================================================
// PC Branch
// ===================================================================================================================
module pc_branch (
    input  [31:0] current_pc,
    input  [31:0] imm_ext,
    output [31:0] pc_branch
);
    assign pc_branch = current_pc + imm_ext;
endmodule


// ===================================================================================================================
// Debouncer Estabilizado
// ===================================================================================================================
module debouncer (
    input  clk_50M, 
    input  btn_in,  
    output reg btn_out 
);
    reg [19:0] count;
    reg btn_sync_0, btn_sync_1;
    
    initial begin
        count = 0;
        btn_out = 1;
        btn_sync_0 = 1;
        btn_sync_1 = 1;
    end

    always @(posedge clk_50M) begin
        btn_sync_0 <= btn_in;
        btn_sync_1 <= btn_sync_0; 
        
        if (btn_sync_1 == btn_out) begin
            count <= 0;
        end else begin
            count <= count + 1;
            if (count == 20'd1_000_000) begin 
                btn_out <= btn_sync_1;
                count <= 0;
            end
        end
    end
endmodule


// ===================================================================================================================
// MÓDULO TOP-LEVEL INTEGRADO
// ===================================================================================================================
module TP2 (
    input        CLOCK_50, 
    input        clk,      
    input        reset,    
    output [6:0] HEX0,     // VALOR x1 - Unidade
    output [6:0] HEX1,     // VALOR x1 - Dezena
    output [6:0] HEX2,     // VALOR x1 - Centena
    output [6:0] HEX3,     // VALOR x1 - Milhar
    output [6:0] HEX4,     // PC - Unidade
    output [6:0] HEX5      // PC - Dezena
);
    wire clock_filtrado;
    wire [31:0] pc_atual, prox_pc, pc4, pc_br;
    wire [31:0] instrucao;
    wire [31:0] dado_reg1, dado_reg2, dado_w;
    wire [31:0] imediato;
    wire [31:0] alu_b, alu_res;
    wire [31:0] mem_dado;
    wire [3:0]  alu_comando;
    wire [1:0]  op_alu;
    wire        w_reg, r_mem, w_mem, src_alu, m_to_reg, m_branch, zero_flag, sinal_pcsrc;
    wire        stop_sinal;
    
    wire [31:0] valor_x1;

    debouncer filtro_inst (
        .clk_50M(CLOCK_50),
        .btn_in(clk),
        .btn_out(clock_filtrado)
    );

    // ===============================================================================================================
    // LÓGICA DE EXIBIÇÃO INTEGRADA
    // ===============================================================================================================
    
    // 1. Program Counter (PC / 4) mapeado para HEX5 e HEX4
    wire [31:0] numero_instrucao = pc_atual >> 2;
    assign stop_sinal = (numero_instrucao > 63) ? 1'b1 : (instrucao == 32'b0);

    reg [3:0] pc_unidade;
    reg [3:0] pc_dezena;

    always @(*) begin
        pc_dezena  = (numero_instrucao / 10) % 10;
        pc_unidade = numero_instrucao % 10;        
    end

    // 2. Exibição Contínua do Registrador x1 mapeada para HEX3, HEX2, HEX1, HEX0
    wire [15:0] x1_exibir = valor_x1[15:0];

    reg [3:0] x1_unidade;
    reg [3:0] x1_dezena;
    reg [3:0] x1_centena;
    reg [3:0] x1_milhar;

    always @(*) begin
        x1_milhar  = (x1_exibir / 1000) % 10;
        x1_centena = (x1_exibir / 100) % 10;  
        x1_dezena  = (x1_exibir / 10) % 10;   
        x1_unidade = x1_exibir % 10;
    end

    // ===============================================================================================================

    pc pc_inst (
        .clk(clock_filtrado), .reset(reset), .stop(stop_sinal), .next_pc(prox_pc), .current_pc(pc_atual)
    );

    pc_plus4 pc4_inst (
        .current_pc(pc_atual), .pc_plus4(pc4)
    );

    instr_mem imem_inst (
        .addr(pc_atual), .instruction(instrucao)
    );

    control ctrl_inst (
        .opcode(instrucao[6:0]),
        .reg_write(w_reg), .mem_read(r_mem), .mem_write(w_mem),
        .alu_src(src_alu), .mem_to_reg(m_to_reg), .branch(m_branch), .alu_op(op_alu)
    );

    reg_file regs_inst (
        .clk(clock_filtrado), 
        .reset(reset),
        .reg_write(w_reg),
        .rs1(instrucao[19:15]), .rs2(instrucao[24:20]), .rd(instrucao[11:7]),
        .write_data(dado_w), .read_data1(dado_reg1), .read_data2(dado_reg2),
        .reg_x1(valor_x1) 
    );

    imm_gen imm_inst (
        .instruction(instrucao), .imm_ext(imediato)
    );

    mux_alu_src mux_alu_inst (
        .read_data2(dado_reg2), .imm_ext(imediato), .alu_src(src_alu), .b(alu_b)
    );

    alu_control aluctrl_inst (
        .alu_op(op_alu), .funct3(instrucao[14:12]), .funct7(instrucao[31:25]), .alu_ctrl(alu_comando)
    );

    alu alu_inst (
        .a(dado_reg1), .b(alu_b), .alu_ctrl(alu_comando), .result(alu_res), .zero(zero_flag)
    );

    data_mem dmem_inst (
        .clk(clock_filtrado), .mem_read(r_mem), .mem_write(w_mem),
        .addr(alu_res), .write_data(dado_reg2), .read_data(mem_dado)
    );

    mux_mem_to_reg mux_wdata_inst (
        .alu_result(alu_res), .mem_read_data(mem_dado), .mem_to_reg(m_to_reg), .write_data(dado_w)
    );

    branch_ctrl brctrl_inst (
        .branch(m_branch), .zero(zero_flag), .pcsrc(sinal_pcsrc)
    );

    pc_branch pcbr_inst (
        .current_pc(pc_atual), .imm_ext(imediato), .pc_branch(pc_br)
    );

    mux_pcsrc mux_pc_inst (
        .pc_plus4(pc4), .pc_branch(pc_br), .pcsrc(sinal_pcsrc), .next_pc(prox_pc)
    );

    // Displays do Program Counter (PC)
    dec7seg_decimal decoder_pc_dezena  (.digito(pc_dezena),  .seg(HEX5));
    dec7seg_decimal decoder_pc_unidade (.digito(pc_unidade), .seg(HEX4));

    // Displays do Registrador x1
    dec7seg_decimal decoder_x1_milhar  (.digito(x1_milhar),  .seg(HEX3));
    dec7seg_decimal decoder_x1_centena (.digito(x1_centena), .seg(HEX2));
    dec7seg_decimal decoder_x1_dezena  (.digito(x1_dezena),  .seg(HEX1));
    dec7seg_decimal decoder_x1_unidade (.digito(x1_unidade), .seg(HEX0));

endmodule